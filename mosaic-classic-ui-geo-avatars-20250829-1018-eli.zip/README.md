# Mosaic — classic grid with avatars
- Space background + planet
- Cards with **avatar (first name only via ui-avatars.com)**, name, `knock` + `prove`, and `ring = days since proof`
- Geolocation weather pill (Open-Meteo)

Deployed: 2025-08-29 10:18 UTC


const knock = document.getElementById('knock');
const proof = document.getElementById('proof');
const toast = document.getElementById('toast');
function flash(msg){ toast.textContent = msg; toast.hidden=false; setTimeout(()=>toast.hidden=true, 1200); }
knock?.addEventListener('click', ()=> flash('🔔 Knock sent!'));
proof?.addEventListener('click', ()=> flash('✅ Proof pinged!'));
console.log('OurMosaic minimal bundle loaded.')

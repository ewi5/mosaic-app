document.addEventListener("DOMContentLoaded", () => {
  console.log("Mosaic app initialized.");
});
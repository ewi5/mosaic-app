
const knock = document.getElementById('knock');
const proof = document.getElementById('proof');
const toast = document.getElementById('toast');
function flash(msg){ toast.textContent = msg; toast.hidden=false; setTimeout(()=>toast.hidden=true, 1200); }
knock?.addEventListener('click', ()=> flash('🔔 Knock sent!'));
proof?.addEventListener('click', ()=> flash('✅ Proof pinged!'));

// Weather demo (static random weather)
const weatherStates = [
  {icon:"☀️", text:"Sunny"},
  {icon:"🌧️", text:"Rainy"},
  {icon:"⛅", text:"Partly Cloudy"},
  {icon:"❄️", text:"Snowy"},
  {icon:"🌩️", text:"Stormy"}
];
const choice = weatherStates[Math.floor(Math.random()*weatherStates.length)];
document.querySelector('#weather .icon').textContent = choice.icon;
document.getElementById('weather-text').textContent = choice.text;

console.log('Mosaic named weather build loaded.')
